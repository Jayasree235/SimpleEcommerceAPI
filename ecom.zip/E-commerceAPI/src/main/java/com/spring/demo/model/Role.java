package com.spring.demo.model;

public enum Role {
	ADMIN, CUSTOMER
}
