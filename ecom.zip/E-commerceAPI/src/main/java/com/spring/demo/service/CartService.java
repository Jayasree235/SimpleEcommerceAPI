package com.spring.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.demo.model.CartItem;
import com.spring.demo.model.Product;
import com.spring.demo.model.User;
import com.spring.demo.repository.CartRepository;
import com.spring.demo.repository.ProductRepository;
import com.spring.demo.repository.UserRepository;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private UserRepository userRepository;

    public CartItem addToCart(String username, Long productId, int quantity) {
        User user = userRepository.findByUsername(username).orElseThrow();
        Product product = productRepository.findById(productId).orElseThrow();
        CartItem item = new CartItem(user, product, quantity);
        return cartRepository.save(item);
    }

    public List<CartItem> getCart(String username) {
        User user = userRepository.findByUsername(username).orElseThrow();
        return cartRepository.findByUser(user);
    }

    public void removeCartItem(Long itemId) {
        cartRepository.deleteById(itemId);
    }

    public void clearCart(String username) {
        User user = userRepository.findByUsername(username).orElseThrow();
        cartRepository.deleteByUser(user);
    }
}
