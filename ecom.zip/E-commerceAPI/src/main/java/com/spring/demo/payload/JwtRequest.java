package com.spring.demo.payload;

public class JwtRequest {

}
